from queuelib.queue import FifoDiskQueue, LifoDiskQueue
from queuelib.pqueue import PriorityQueue
